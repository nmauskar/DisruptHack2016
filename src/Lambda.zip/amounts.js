module.exports = {
  "cheese": "You have eight ounces of cheese left.",
  "pizza dough": "You have nine ounces of pizza dough left.",
  "tomato sauce": "You have eleven ounces of tomato sauce left.",
  "pasta": "You have thirteen ounces of pasta left.",
  "lettuce": "You have twenty ounces of lettuce left.",
  "tomato": "You have seven ounces of tomato left.",
  "carrots": "You have two ounces of carrots left."
}
